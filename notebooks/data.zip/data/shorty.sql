-- psql 'dbname=mimic' -f shorty.sql

DROP TABLE IF EXISTS FIRSTNAMES CASCADE;
CREATE TABLE FIRSTNAMES
(
  firstname VARCHAR(50) NOT NULL,
  frequency INT NOT NULL,
  subject_id INT NOT NULL
);

\copy FIRSTNAMES from 'firstname.csv' delimiter ',' csv header NULL ''

DROP TABLE IF EXISTS NAMES CASCADE;
CREATE TABLE NAMES
(
  name VARCHAR(50) NOT NULL,
  frequency INT NOT NULL,
  subject_id INT NOT NULL
);

\copy NAMES from 'name.csv' delimiter ',' csv header NULL ''


DROP TABLE IF EXISTS ADDRESSES CASCADE;
CREATE TABLE ADDRESSES
(
  nb VARCHAR(50),
  road VARCHAR(250),
  postcode VARCHAR(50),
  city VARCHAR(50),
  subject_id INT NOT NULL
);

\copy ADDRESSES from 'address.csv' delimiter ',' csv header NULL ''


